# django_management_commands_logging
This is a Python package for modularizing standard loggers when using Django's management commands.
