from django_management_commands_logging.core import (
    LoggingBaseCommand,
    enable_logging
)